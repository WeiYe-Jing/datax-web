create
    definer = root@`%` procedure test()
begin
declare i int;		
set i=6001;
while i<101 do		
	INSERT INTO goodsdoc (GoodeCode,GoodeName) VALUES ('01010001','阿莫西林胶囊'); 
set i=i+1;		
end while;
end;

