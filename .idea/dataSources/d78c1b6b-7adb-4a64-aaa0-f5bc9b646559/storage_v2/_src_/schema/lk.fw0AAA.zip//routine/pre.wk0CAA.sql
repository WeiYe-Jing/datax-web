create
    definer = root@`%` procedure pre()
begin
declare i int;		
set i=6001;
while i<101 do		
	insert into assisted_material (id,name,edition_id,stages_id,grade_id,subject_id,volume,type,status,price,chapter_id,publisher)
	values(i,'老师课本+',111,2,2,1,'3','material','enabled','50',3,'人民出版社'); 
set i=i+1;		
end while;
end;

